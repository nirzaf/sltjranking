<?php
/*
Plugin Name: Localsync Client
Version: 1.0
Text Domain: localsync-client
Author: Revmakx
Author URI: https://localsync.io
Description: This is a Localsync Client Plugin.
*/

if(!function_exists('request_filesystem_credentials')){
    include_once ABSPATH . 'wp-admin/includes/file.php';
}

$creds = request_filesystem_credentials("", "", false, false, null);
if (false === $creds) {
    return false;
}

if (!WP_Filesystem($creds)) {
    return false;
}

class LS_Client
{
    private $plugin_name;
    private $version;
    public function __construct()
    {
        $this->plugin_name = 'Localsync Client';
        $this->version     = '1.0';
        
        add_action('admin_init', array(
            $this,
            'ls_client_install'
        ), 5);
    }
    

   public function ls_client_succ_notice()
    {
        ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.7.1/clipboard.min.js"></script>
        <style>
        #message {
        	display:none;
        }
    </style>
        <script>
        new Clipboard('#btn_localsync');
        function removeLSButton()
        {
        	jQuery("#ls_btn_div").fadeIn(200).fadeOut(2000);
        }
        </script>
        <div class="notice notice-success is-dismissible" style="text-align: center; display:block !important; ">
        	<p style="color: green; font-size: 14px; font-weight: bold;">Add this site to LocalSync</p><p>
		</p><table border="0" align="center" cellpadding="5"><tbody>
			<tr><td align="center">Remote Site URL: <strong><?php echo site_url(); ?></strong></td></tr>
           <tr><td align="center" style="position:relative;"><div id="btn_localsync" data-clipboard-text="<?php echo site_url();?>" onclick= "removeLSButton();" style="background:#008000;display: inline-block;padding: 4px 10px;border-radius: 5px;color:#fff;font-weight:600;cursor:pointer;">Copy details</div><span class="copy_message" id="ls_btn_div" style="display:none;margin-left:10px;color:#008000;">Copied :)</span></td></tr><tr><td><i>The setup is complete, so this plugin has been deactivated & deleted automatically</i></td></tr>
</tbody></table>
	  	<p></p>
           
        </div>
        <?php
    }

    public function ls_client_error_notice()
    {
        ?>
        <div class="error notice is-dismissible" style="text-align: center">
        	<p style="color: green; font-size: 14px; font-weight: bold;">Add this site to LocalSync</p><p></p>
            <p><?php _e('PHP is not able to write files on your WordPress directory. Try again after changing the file permissions or please continue by choosing FTP in the LocalSync App. This plugin has been deactivated & deleted automatically.', 'localsync-client'); ?></p>
        </div>
        <?php
    }

    public function ls_client_install()
    {
        if( $this->ls_client_create_ls() && $this->ls_client_create_temp_dir() && $this->ls_client_create_ls_config() ){
            add_action('admin_notices', array(
                $this,
                'ls_client_succ_notice'
            ));
            $this->ls_client_remove_plugin();
        }else{
            add_action('admin_notices', array(
                $this,
                'ls_client_error_notice'
            ));
        }
    }

    public function ls_client_remove_plugin()
    {
        @deactivate_plugins( plugin_basename( __FILE__ ) );
        @delete_plugins( array(plugin_basename( __FILE__ ))  );
    }


    public function ls_client_create_ls(){
        global $wp_filesystem;
        $isput = false;

        $filename = plugin_dir_path( __FILE__ ) . 'localsync.php';
        $destination = ABSPATH . 'localsync.php';

        $file = $wp_filesystem->get_contents( $filename );

        $isput = $wp_filesystem->put_contents(
            $destination,
            $file,
            FS_CHMOD_FILE 
        );

        if( $isput ){
            return true;
        }
        return false;
    }

    public function ls_client_create_ls_config(){
        global $wp_filesystem;
        $isput = false;

        $filename = plugin_dir_path( __FILE__ ) . 'ls-config.php';
        $destination = ABSPATH . 'ls-config.php';

        $file = $wp_filesystem->get_contents( $filename );

        $isput = $wp_filesystem->put_contents(
            $destination,
            $file,
            FS_CHMOD_FILE 
        );

        if( $isput ){
            return true;
        }
        return false;
    }

    public function ls_client_create_temp_dir(){
        $permission = 0777;
        $destination = ABSPATH . '/ls_temp';

        if( ! is_dir($destination) ){
            if( mkdir($destination, $permission) ){
                return true;
            }
        }else{
            return true;
        }
        return false;
    }

}

$ls = new LS_Client();